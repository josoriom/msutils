import type { Backend, FileHandle } from "./backend";
/**
 * A loaded sample file. Holds an internal handle to the native
 * file object. Cleanup is automatic, but call {@link dispose} when
 * you're done with large samples or tight processing loops to free memory sooner.
 */
export declare class SampleFile {
    /** @internal */
    _backend: Backend;
    private _cell;
    constructor(handle: FileHandle, backend: Backend);
    get _handle(): FileHandle | null;
    /**
     * Release the native memory held by this sample.
     */
    dispose(): void;
    /**
     * Return the sample data as a plain JavaScript object.
     * @returns Parsed sample data with camelCase keys.
     */
    toJson(): any;
    /**
     * Serialize the sample back to mzML format.
     * @returns Full mzML file content as a string.
     */
    toMzml(): string;
    /**
     * Encode the sample as compressed ion binary bytes.
     *
     * @param options - Encoding options.
     * @param options.level - Compression level, 0 (none) to 22 (max). Default 12.
     * @param options.f32Compress - Compress intensity values to 32-bit float. Default false.
     * @returns Raw ion binary bytes.
     */
    toIon(options?: {
        level?: number;
        f32Compress?: boolean;
    }): Uint8Array;
    private assertValid;
}
//# sourceMappingURL=sampleFile.d.ts.map