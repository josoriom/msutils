import type { Backend, FileHandle } from "./backend";
export declare class MzMlFile {
    /** @internal */
    _handle: FileHandle | null;
    /** @internal */
    _backend: Backend;
    constructor(handle: FileHandle, backend: Backend);
    dispose(): void;
    toJson(): any;
    toMzml(): string;
    toBin(level?: number, f32Compress?: boolean): Uint8Array;
    private assertValid;
}
//# sourceMappingURL=mzmlFile.d.ts.map