import type { IonInput } from "../types/types";
export type IonSource = {
    kind: "path";
    path: string;
} | {
    kind: "url";
    url: URL;
} | {
    kind: "buffer";
    bytes: Uint8Array;
};
export declare function getIonSource(input: IonInput): IonSource;
//# sourceMappingURL=ionSource.d.ts.map