import { ContainmentCache } from "./containmentCache";
type FreeCell<H> = {
    handle: H | null;
    free: (h: H) => void;
};
export interface HandleEntry {
    cache: ContainmentCache;
}
declare class HandleRegistry<H> {
    private readonly registry;
    private readonly metadata;
    constructor();
    register(owner: object, handle: H, free: (h: H) => void): FreeCell<H>;
    release(owner: object, cell: FreeCell<H>): void;
    get_entry(handle: H): HandleEntry;
    with_lock<T>(handle: H, fn: (entry: HandleEntry) => Promise<T>): Promise<T>;
}
export declare const fileHandleRegistry: HandleRegistry<unknown>;
export {};
//# sourceMappingURL=handleRegistry.d.ts.map