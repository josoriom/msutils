import type { PeakOptions, Target } from "../types/types";
export declare function packPeakOptions(opts?: PeakOptions): Uint8Array | undefined;
export declare function encodeTargetIds(ids: string[]): {
    packedBytes: Uint8Array;
    offsets: Uint32Array;
    lengths: Uint32Array;
};
export declare function unpackTargets(targets: Target[], defaultRange?: number): {
    rts: Float64Array;
    mzs: Float64Array;
    ranges: Float64Array;
    ids: string[];
};
//# sourceMappingURL=pack.d.ts.map